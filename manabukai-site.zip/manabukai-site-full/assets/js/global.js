
document.addEventListener('DOMContentLoaded',()=>{
  const torii=document.getElementById('torii');
  if(torii){
    torii.style.cursor='pointer';
    torii.addEventListener('click',()=>window.location.href='home.html');
  }
  const navToggle=document.getElementById('navToggle');
  const nav=document.getElementById('nav');
  if(navToggle && nav){
    navToggle.addEventListener('click',()=>{
      const open=nav.classList.toggle('show');
      navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
});
