
let cart=[];
function addToCart(name,price){cart.push({name,price});updateCart();}
function updateCart(){
  const list=document.getElementById('cartItems');
  const totalEl=document.getElementById('total');
  if(!list||!totalEl) return;
  list.innerHTML=''; let total=0;
  cart.forEach(item=>{ total+=item.price; const li=document.createElement('li'); li.textContent=`${item.name} — R$ ${item.price.toFixed(2)}`; list.appendChild(li); });
  totalEl.textContent=`Total: R$ ${total.toFixed(2)}`;
}
function checkout(){
  if(cart.length===0){alert('Seu carrinho está vazio!');return;}
  alert('Compra simulada com sucesso! Obrigado 🙏');
  cart=[]; updateCart();
}
window.addToCart=addToCart; window.checkout=checkout;
