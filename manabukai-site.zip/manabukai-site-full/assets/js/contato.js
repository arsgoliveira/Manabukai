
document.addEventListener('DOMContentLoaded',()=>{
  const form=document.getElementById('contactForm');
  const message=document.getElementById('formMessage');
  if(form){
    form.addEventListener('submit',e=>{
      e.preventDefault();
      if(message){message.style.display='block';}
      form.reset();
    });
  }
});
